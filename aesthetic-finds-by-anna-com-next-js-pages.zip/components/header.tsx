"use client"

import Link from "next/link"
import { useEffect, useState } from "react"

export default function Header() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 bg-white transition-all duration-300 ${scrolled ? "h-16 shadow-sm" : "h-20"}`}
    >
      <div className="mx-auto flex h-full max-w-7xl items-center justify-between px-6">
        <Link href="/" className="font-serif text-xl text-foreground transition-colors hover:text-accent md:text-2xl">
          Aesthetic Finds by Anna
        </Link>

        <nav className="flex items-center gap-8">
          <Link href="/" className="text-sm font-medium text-foreground transition-colors hover:text-accent">
            Home
          </Link>
          <Link href="/blog" className="text-sm font-medium text-foreground transition-colors hover:text-accent">
            Blog
          </Link>
        </nav>
      </div>
    </header>
  )
}
