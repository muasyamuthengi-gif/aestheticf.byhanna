import Link from "next/link"
import Image from "next/image"

interface CategoryCardProps {
  title: string
  href: string
  imageUrl: string
}

export default function CategoryCard({ title, href, imageUrl }: CategoryCardProps) {
  return (
    <Link href={href} className="group relative block overflow-hidden">
      <div className="relative aspect-[3/4]">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 p-6">
          <h3 className="font-serif text-2xl text-white text-balance md:text-3xl">{title}</h3>
        </div>
      </div>
    </Link>
  )
}
