export default function Footer() {
  return (
    <footer className="border-t border-border bg-white py-12">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center">
          <p className="font-serif text-xl text-foreground">Aesthetic Finds by Anna</p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Curated aesthetics for interiors that feel intentional and timeless.
          </p>
          <p className="mt-8 text-xs text-muted-foreground">
            © {new Date().getFullYear()} Aesthetic Finds by Anna. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
