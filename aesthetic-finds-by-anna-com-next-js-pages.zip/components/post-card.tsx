import Link from "next/link"
import Image from "next/image"

interface PostCardProps {
  title: string
  slug: string
  excerpt?: string
  imageUrl: string
  date: string
}

export default function PostCard({ title, slug, excerpt, imageUrl, date }: PostCardProps) {
  return (
    <Link href={`/blog/${slug}`} className="group block">
      <div className="relative aspect-[3/4] overflow-hidden">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
      </div>
      <div className="mt-4">
        <time className="text-xs uppercase tracking-wider text-muted-foreground">{date}</time>
        <h3 className="mt-2 font-serif text-2xl leading-tight text-foreground text-balance group-hover:text-accent transition-colors">
          {title}
        </h3>
        {excerpt && <p className="mt-2 text-sm leading-relaxed text-muted-foreground line-clamp-2">{excerpt}</p>}
      </div>
    </Link>
  )
}
