import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import PostCard from "@/components/post-card"

// This would come from your MDX or CMS in production
async function getPost(slug: string) {
  // Mock data for demonstration
  return {
    title: "Creating a Calm Living Space with Neutral Tones",
    date: "December 15, 2025",
    intro:
      "Transform your living room into a peaceful sanctuary with a carefully curated neutral palette. Discover the power of subtle tones, natural materials, and intentional design choices.",
    heroImage: "/modern-neutral-living-room-with-natural-light-and-.jpg",
    content: [
      {
        type: "text",
        heading: "The Foundation of Neutral Design",
        text: "Neutral tones create a sense of calm and timelessness in any living space. The key is to layer different shades of whites, beiges, and warm grays to add depth without overwhelming the senses. Start with a base of crisp white walls, then introduce warmer neutrals through furniture, textiles, and accessories.",
      },
      {
        type: "image",
        url: "/placeholder.svg?height=1000&width=800&query=neutral sofa with textured pillows and throw blanket",
        alt: "Neutral sofa with layered textures",
      },
      {
        type: "text",
        heading: "Texture is Everything",
        text: "When working with a neutral palette, texture becomes your best friend. Mix linen, wool, cotton, and natural fibers to create visual interest. A chunky knit throw, smooth leather accent chair, and woven basket all work together to add dimension to your space without introducing color.",
      },
      {
        type: "image",
        url: "/placeholder.svg?height=1000&width=800&query=close up of layered neutral textiles linen wool cotton",
        alt: "Layered neutral textures",
      },
      {
        type: "text",
        heading: "Natural Elements Bring Warmth",
        text: "Incorporate natural wood tones, stone, and greenery to prevent your neutral space from feeling cold or sterile. A solid wood coffee table, ceramic vases, and potted plants add organic warmth and life to the room. These elements ground the space and create a connection to nature.",
      },
      {
        type: "image",
        url: "/placeholder.svg?height=1000&width=800&query=living room with wood coffee table plants and natural materials",
        alt: "Natural materials in neutral living room",
      },
      {
        type: "text",
        heading: "The Power of Lighting",
        text: "Soft, warm lighting is essential in a neutral living space. Layer different light sources—ambient, task, and accent lighting—to create depth and ambiance. Consider warm-toned bulbs, natural woven pendant lights, and candles to enhance the cozy atmosphere.",
      },
    ],
  }
}

// Related posts mock data
const relatedPosts = [
  {
    title: "The Art of Layering Textures in the Bedroom",
    slug: "layering-textures-bedroom",
    imageUrl: "/cozy-bedroom-with-layered-linen-and-wool-textures.jpg",
    date: "Dec 5, 2025",
  },
  {
    title: "Natural Materials for Warm Interior Spaces",
    slug: "natural-materials-warm-interiors",
    imageUrl: "/interior-with-natural-wood-stone-and-linen.jpg",
    date: "Nov 25, 2025",
  },
  {
    title: "Minimalist Kitchen Organization Tips",
    slug: "minimalist-kitchen-organization",
    imageUrl: "/minimalist-white-kitchen-with-open-shelving.jpg",
    date: "Dec 1, 2025",
  },
]

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const post = await getPost(slug)

  return (
    <main>
      {/* Hero Image */}
      <div className="relative aspect-[16/9] w-full md:aspect-[21/9]">
        <Image src={post.heroImage || "/placeholder.svg"} alt={post.title} fill priority className="object-cover" />
      </div>

      {/* Article Content */}
      <article className="mx-auto max-w-3xl px-6 py-12 md:py-16">
        <header className="mb-12 text-center">
          <time className="text-sm uppercase tracking-wider text-muted-foreground">{post.date}</time>
          <h1 className="mt-4 font-serif text-4xl leading-tight text-foreground text-balance md:text-5xl lg:text-6xl">
            {post.title}
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground text-pretty">
            {post.intro}
          </p>
        </header>

        <div className="prose prose-lg max-w-none">
          {post.content.map((section, index) => (
            <div key={index} className="mb-12">
              {section.type === "text" && (
                <>
                  <h2 className="mb-4 font-serif text-3xl text-foreground">{section.heading}</h2>
                  <p className="leading-relaxed text-muted-foreground">{section.text}</p>
                </>
              )}
              {section.type === "image" && (
                <div className="relative -mx-6 my-12 aspect-[4/5] md:-mx-12">
                  <Image src={section.url || "/placeholder.svg"} alt={section.alt} fill className="object-cover" />
                </div>
              )}
            </div>
          ))}
        </div>
      </article>

      {/* Related Posts */}
      <section className="border-t border-border bg-secondary py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="mb-12 text-center font-serif text-3xl text-foreground md:text-4xl">Continue Reading</h2>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {relatedPosts.map((post) => (
              <PostCard key={post.slug} {...post} />
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button
              asChild
              variant="outline"
              className="border-foreground text-foreground hover:bg-foreground hover:text-white bg-transparent"
            >
              <Link href="/blog">View All Posts</Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}

// Generate static params for all blog posts (optional, for static generation)
export async function generateStaticParams() {
  // In production, fetch all post slugs from your CMS or MDX files
  return [
    { slug: "calm-living-space-neutral-tones" },
    { slug: "welcoming-entryway-essentials" },
    { slug: "spa-inspired-bathroom-design" },
    { slug: "layering-textures-bedroom" },
  ]
}
