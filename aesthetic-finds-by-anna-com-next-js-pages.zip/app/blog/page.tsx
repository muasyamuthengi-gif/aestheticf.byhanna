import PostCard from "@/components/post-card"

export const metadata = {
  title: "Blog - Aesthetic Finds by Anna",
  description: "Explore our collection of modern home decor ideas and interior design inspiration.",
}

export default function BlogPage() {
  // Mock data - replace with your actual data source (MDX, CMS, etc.)
  const posts = [
    {
      title: "Creating a Calm Living Space with Neutral Tones",
      slug: "calm-living-space-neutral-tones",
      excerpt:
        "Discover how to transform your living room into a peaceful sanctuary using a carefully curated neutral palette.",
      imageUrl: "/calm-neutral-living-room-with-textures.jpg",
      date: "Dec 15, 2025",
    },
    {
      title: "Essential Elements for a Welcoming Entryway",
      slug: "welcoming-entryway-essentials",
      excerpt: "First impressions matter. Learn the key pieces that make your entryway both functional and beautiful.",
      imageUrl: "/modern-entryway-with-bench-and-hooks.jpg",
      date: "Dec 12, 2025",
    },
    {
      title: "Spa-Inspired Bathroom Design Ideas",
      slug: "spa-inspired-bathroom-design",
      excerpt: "Turn your bathroom into a luxurious retreat with these simple yet impactful design choices.",
      imageUrl: "/spa-bathroom-with-natural-wood-and-plants.jpg",
      date: "Dec 8, 2025",
    },
    {
      title: "The Art of Layering Textures in the Bedroom",
      slug: "layering-textures-bedroom",
      excerpt: "Create depth and warmth in your bedroom by mastering the art of textile and texture layering.",
      imageUrl: "/cozy-bedroom-with-layered-linen-and-wool-textures.jpg",
      date: "Dec 5, 2025",
    },
    {
      title: "Minimalist Kitchen Organization Tips",
      slug: "minimalist-kitchen-organization",
      excerpt: "Achieve a clutter-free kitchen that is both beautiful and highly functional with these essential tips.",
      imageUrl: "/minimalist-white-kitchen-with-open-shelving.jpg",
      date: "Dec 1, 2025",
    },
    {
      title: "How to Style Open Shelving in Your Home",
      slug: "styling-open-shelving",
      excerpt: "Master the art of displaying your favorite pieces while maintaining a clean, curated aesthetic.",
      imageUrl: "/styled-open-shelving-with-ceramics-and-plants.jpg",
      date: "Nov 28, 2025",
    },
    {
      title: "Natural Materials for Warm Interior Spaces",
      slug: "natural-materials-warm-interiors",
      excerpt: "Explore how wood, stone, and linen can transform your home into a warm, inviting sanctuary.",
      imageUrl: "/interior-with-natural-wood-stone-and-linen.jpg",
      date: "Nov 25, 2025",
    },
    {
      title: "Creating Cozy Corners for Reading",
      slug: "cozy-reading-corners",
      excerpt: "Design the perfect reading nook that invites you to slow down and enjoy a good book.",
      imageUrl: "/cozy-reading-corner-with-armchair-and-lamp.jpg",
      date: "Nov 22, 2025",
    },
  ]

  return (
    <main className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-16 text-center">
          <h1 className="font-serif text-4xl text-foreground md:text-5xl">All Posts</h1>
          <p className="mt-4 text-lg text-muted-foreground">Curated home decor ideas and inspiration</p>
        </div>

        <div className="grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => (
            <PostCard key={post.slug} {...post} />
          ))}
        </div>
      </div>
    </main>
  )
}
